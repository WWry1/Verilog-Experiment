module water_led(
    input wire clk,
    input wire rst,
    input wire freq_ctrl,
    input wire dir_ctrl,
    input wire mode_sel,
    output reg [7:0] led
);
localparam [23:0] CNT_MAX1 = 24'd9_999_999;
localparam [23:0] CNT_MAX2 = 24'd1_999_999;
reg   [23:0]cnt;
wire   cnt_end1;
reg    mode_sel_d;
wire   cnt_end2;

assign  cnt_end1 = (cnt>=CNT_MAX1);
assign  cnt_end2 = (cnt>=CNT_MAX2);

always @(posedge clk or posedge rst) begin
if(rst)
cnt <= 24'd0;
else if(freq_ctrl == 0) begin
if(cnt_end1)
cnt <= 24'd0;
else
cnt <= cnt + 24'd1;
end
else if(freq_ctrl == 1) begin
if(cnt_end2)
 cnt <= 24'd0;
 else
cnt <= cnt + 24'd1;
end
end

always @(posedge clk or posedge rst) begin
    if(rst) begin
        mode_sel_d <= mode_sel;
            led <= 8'h01;  
    end
    else begin
        mode_sel_d <= mode_sel;
        if(mode_sel != mode_sel_d) begin
            if(mode_sel == 0)
                led <= 8'h01;
            else
                led <= 8'h03;
        end
        else begin
            if(freq_ctrl == 0) begin

                if(dir_ctrl == 0 && mode_sel == 0) begin
                    if(cnt_end1)
                        led <= {led[0], led[7:1]};
                end

                if(dir_ctrl == 0 && mode_sel == 1) begin
                    if(cnt_end1)
                        led <= {led[1:0], led[7:2]};
                end

                if(dir_ctrl == 1 && mode_sel == 0) begin
                    if(cnt_end1)
                        led <= {led[6:0], led[7]};
                end

                if(dir_ctrl == 1 && mode_sel == 1) begin
                    if(cnt_end1)
                        led <= {led[5:0], led[7:6]};
                end

            end

            if(freq_ctrl == 1) begin

                if(dir_ctrl == 0 && mode_sel == 0) begin
                    if(cnt_end2)
                        led <= {led[0], led[7:1]};
                end

                if(dir_ctrl == 0 && mode_sel == 1) begin
                    if(cnt_end2)
                        led <= {led[1:0], led[7:2]};
                end

                if(dir_ctrl == 1 && mode_sel == 0) begin
                    if(cnt_end2)
                        led <= {led[6:0], led[7]};
                end

                if(dir_ctrl == 1 && mode_sel == 1) begin
                    if(cnt_end2)
                        led <= {led[5:0], led[7:6]};
                end

            end
        end
    end
end
endmodule