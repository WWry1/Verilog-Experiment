`timescale 1ns / 1ps

module tb_water_led;

    reg clk;
    reg rst;
    reg freq_ctrl;
    reg dir_ctrl;
    reg mode_sel;
    wire [7:0] led;

    water_led uut (
        .clk(clk),
        .rst(rst),
        .freq_ctrl(freq_ctrl),
        .dir_ctrl(dir_ctrl),
        .mode_sel(mode_sel),
        .led(led)
    );

    // 100 MHz clock: period = 10 ns.
    initial clk = 1'b0;
    always #5 clk = ~clk;

    // Delays below are in ns. Each mode is observed for three updates.
    // Reset before each mode keeps tests independent and avoids the
    // speed-switch issue caused by == in the original counter logic.
    initial begin
        rst       = 1'b1;
        freq_ctrl = 1'b0;
        dir_ctrl  = 1'b0;
        mode_sel  = 1'b0;

        // 1. 0.1 s, rotate right by one bit.
        // 01 -> 80 -> 40 -> 20
        #20;
        rst = 1'b0;
        #300_000_000;

        // 2. 0.1 s, rotate right by two bits.
        // 01 -> 40 -> 10 -> 04
        rst = 1'b1;
        mode_sel = 1'b1;
        #20;
        rst = 1'b0;
        #300_000_000;

        // 3. 0.1 s, rotate left by one bit.
        // 01 -> 02 -> 04 -> 08
        rst = 1'b1;
        dir_ctrl = 1'b1;
        mode_sel = 1'b0;
        #20;
        rst = 1'b0;
        #300_000_000;

        // 4. 0.1 s, rotate left by two bits.
        // 01 -> 04 -> 10 -> 40
        rst = 1'b1;
        mode_sel = 1'b1;
        #20;
        rst = 1'b0;
        #300_000_000;

        // 5. 0.02 s, rotate right by one bit.
        // 01 -> 80 -> 40 -> 20
        rst = 1'b1;
        freq_ctrl = 1'b1;
        dir_ctrl = 1'b0;
        mode_sel = 1'b0;
        #20;
        rst = 1'b0;
        #60_000_000;

        // 6. 0.02 s, rotate right by two bits.
        // 01 -> 40 -> 10 -> 04
        rst = 1'b1;
        mode_sel = 1'b1;
        #20;
        rst = 1'b0;
        #60_000_000;

        // 7. 0.02 s, rotate left by one bit.
        // 01 -> 02 -> 04 -> 08
        rst = 1'b1;
        dir_ctrl = 1'b1;
        mode_sel = 1'b0;
        #20;
        rst = 1'b0;
        #60_000_000;

        // 8. 0.02 s, rotate left by two bits.
        // 01 -> 04 -> 10 -> 40
        rst = 1'b1;
        mode_sel = 1'b1;
        #20;
        rst = 1'b0;
        #60_000_000;

        // Check asynchronous reset between clock edges.
        #2;
        rst = 1'b1;
        #20;
        rst = 1'b0;
        #20;

        $finish;
    end

endmodule



