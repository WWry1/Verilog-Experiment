module sender (
    input        clk,
    input        rst,
    input        done,
    input [15:0] result,
    output reg        tx_valid,
    output reg  [7:0] tx_data
);

localparam BAUD = 18'd114587;
reg [2:0] send_cnt;
reg [7:0] digit[0:3];
reg sending ;
reg [17:0] wait_cnt;

always@(posedge clk or posedge rst) begin
    if(rst)begin
          tx_valid<=0; send_cnt<=0; wait_cnt<=0; sending<=0;tx_data<=0; 
    end
    else begin
        tx_valid<=0;
    if(done) begin 
        digit[0]<=(result /1000) +"0";
        digit[1]<=(result %1000 /100) +"0";
        digit[2]<=(result %100 /10) +"0";
        digit[3]<=(result %10) +"0";
        sending<=1;
        send_cnt<=0;
        wait_cnt<=0;
        end
     else if(sending) begin
        if(wait_cnt==0) begin
            tx_valid<=1;
            tx_data<=digit[send_cnt];
            wait_cnt<=1;
            end
        else if(wait_cnt<=BAUD) wait_cnt<=wait_cnt+1;
        else begin
            wait_cnt<=0;
            send_cnt<=send_cnt+1;
            if(send_cnt==3) sending<=0;
             end
   
        end     
    end    
end
endmodule