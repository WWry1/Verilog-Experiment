`timescale 1ns / 1ps

module tb_top;

// ===== 参数 =====
localparam CLK_PERIOD = 10;       // 100MHz时钟，周期10ns
localparam BAUD_CYCLES = 10417;   // 波特率9600对应的时钟周期数

// ===== 信号声明 =====
reg         clk;
reg         rst;
reg         uart_rx;    // 仿真PC发给FPGA的串口
wire        uart_tx;    // FPGA回复给PC的串口
wire [7:0]  led_en;
wire [7:0]  led_cx;

// ===== 实例化顶层 =====
top #(.SCAN_CYCLES(100)) u_top (
    .clk(clk),
    .rst(rst),
    .uart_rx(uart_rx),
    .uart_tx(uart_tx),
    .led_en(led_en),
    .led_cx(led_cx)
);

// ===== 时钟生成 =====
initial clk = 0;
always #(CLK_PERIOD/2) clk = ~clk;

// ===== UART发送一个字节的任务 =====
// 模拟PC通过串口发送一个ASCII字节给FPGA
task uart_send_byte;
    input [7:0] data;
    integer i;
    begin
        // 起始位（低电平）
        uart_rx = 0;
        repeat(BAUD_CYCLES) @(posedge clk);
        // 8个数据位，LSB先发
        for (i = 0; i < 8; i = i + 1) begin
            uart_rx = data[i];
            repeat(BAUD_CYCLES) @(posedge clk);
        end
        // 停止位（高电平）
        uart_rx = 1;
        repeat(BAUD_CYCLES) @(posedge clk);
    end
endtask

// ===== 发送字符串的任务 =====
task uart_send_str;
    input [7*8-1:0] str; // 最多7个字符
    input integer   len;
    integer j;
    reg [7:0] ch;
    begin
        for (j = len-1; j >= 0; j = j - 1) begin
            ch = str[j*8 +: 8];
            uart_send_byte(ch);
        end
    end
endtask

// ===== 监控uart_tx输出 =====
// 收到FPGA回复时打印
reg [7:0] rx_shift;
integer   rx_bit_cnt;
real      rx_start_time;

initial begin
    rx_bit_cnt = -1;  // -1表示等待起始位
end

// 监控线（简单方式：用$monitor打印uart_tx变化）
// 更完整的做法是解码UART，这里用task
task uart_recv_byte;
    output [7:0] data;
    integer k;
    begin
        // 等待起始位下降沿
        @(negedge uart_tx);
        // 等半个bit，采样到中间
        repeat(BAUD_CYCLES/2) @(posedge clk);
        // 确认是起始位
        repeat(BAUD_CYCLES) @(posedge clk);
        // 采样8个数据位
        for (k = 0; k < 8; k = k + 1) begin
            data[k] = uart_tx;
            repeat(BAUD_CYCLES) @(posedge clk);
        end
        // 等停止位结束
        repeat(BAUD_CYCLES/2) @(posedge clk);
    end
endtask

// ===== 主测试流程 =====
reg [7:0] recv_char;
reg [7:0] recv_buf [0:7];
integer   ci;

task recv_and_print;
    input integer num_bytes;
    begin
        $write("  FPGA回复: ");
        for (ci = 0; ci < num_bytes; ci = ci + 1) begin
            uart_recv_byte(recv_char);
            $write("%c", recv_char);
        end
        $display("");
    end
endtask

initial begin
    // 初始化
    uart_rx = 1;  // 串口空闲高电平
    rst = 1;
    repeat(20) @(posedge clk);
    rst = 0;
    repeat(10) @(posedge clk);

    $display("========================================");
    $display("       FPGA 简易计算器 功能仿真");
    $display("========================================");

    // ----- 测试1：12 + 3 = 15 -----
    $display("\n[测试1] 发送: 12+3=");
    uart_send_byte("1");
    uart_send_byte("2");
    uart_send_byte("+");
    uart_send_byte("3");
    uart_send_byte("=");
    recv_and_print(4);  // 期望收到 "0015"

    repeat(BAUD_CYCLES * 5) @(posedge clk);

    // ----- 测试2：36 / 12 = 3 -----
    $display("\n[测试2] 发送: 36/12=");
    uart_send_byte("3");
    uart_send_byte("6");
    uart_send_byte("/");
    uart_send_byte("1");
    uart_send_byte("2");
    uart_send_byte("=");
    recv_and_print(4);  // 期望收到 "0003"

    repeat(BAUD_CYCLES * 5) @(posedge clk);

    // ----- 测试3：9 * 9 = 81 -----
    $display("\n[测试3] 发送: 9*9=");
    uart_send_byte("9");
    uart_send_byte("*");
    uart_send_byte("9");
    uart_send_byte("=");
    recv_and_print(4);  // 期望收到 "0081"

    repeat(BAUD_CYCLES * 5) @(posedge clk);

    // ----- 测试4：99 - 1 = 98 -----
    $display("\n[测试4] 发送: 99-1=");
    uart_send_byte("9");
    uart_send_byte("9");
    uart_send_byte("-");
    uart_send_byte("1");
    uart_send_byte("=");
    recv_and_print(4);  // 期望收到 "0098"

    repeat(BAUD_CYCLES * 5) @(posedge clk);

    // ----- 测试5：连续处理（不复位）-----
    $display("\n[测试5] 连续发送: 5+5= 然后 10*10=");
    uart_send_byte("5");
    uart_send_byte("+");
    uart_send_byte("5");
    uart_send_byte("=");
    recv_and_print(4);  // 期望收到 "0010"

    repeat(BAUD_CYCLES * 3) @(posedge clk);

    uart_send_byte("1");
    uart_send_byte("0");
    uart_send_byte("*");
    uart_send_byte("1");
    uart_send_byte("0");
    uart_send_byte("=");
    recv_and_print(4);  // 期望收到 "0100"

    $display("\n========================================");
    $display("              仿真结束");
    $display("========================================");
    $finish;
end

// ===== 超时保护 =====
initial begin
    #500_000_000;  // 500ms超时
    $display("ERROR: 仿真超时！");
    $finish;
end

// ===== 波形导出（可选）=====
initial begin
    $dumpfile("tb_top.vcd");
    $dumpvars(0, tb_top);
end

endmodule
