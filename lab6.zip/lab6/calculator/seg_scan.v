`timescale 1ns / 1ps
module seg_scan #(
    parameter integer SCAN_CYCLES = 100_000
) (
    input wire clk,
    input wire rst,
    input wire [31:0] display_data,
    output reg [7:0] led_en,
    output reg [7:0] led_cx
);
    localparam integer CNT_LAST_VALUE = SCAN_CYCLES - 1;
    localparam [16:0] CNT_LAST = CNT_LAST_VALUE[16:0];
    reg [16:0] scan_cnt;
    reg [2:0] scan_index;
    reg [3:0] digit;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            scan_cnt <= {17'b0};
            scan_index <= 3'd0;
        end else if (scan_cnt == CNT_LAST) begin
            scan_cnt <= {17'b0};
            scan_index <= scan_index + 3'd1;
        end else begin
            scan_cnt <= scan_cnt + 1'b1;
        end
    end

    always @* begin
        case (scan_index)//每四位是一个数字
            3'd0: digit = display_data[3:0];
            3'd1: digit = display_data[7:4];
            3'd2: digit = display_data[11:8];
            3'd3: digit = display_data[15:12];
            3'd4: digit = display_data[19:16];
            3'd5: digit = display_data[23:20];
            3'd6: digit = display_data[27:24];
            3'd7: digit = display_data[31:28];
            default: digit = 4'd0;
        endcase

        led_en = ~(8'b0000_0001 << scan_index);//因为低电平有效，左移scan_index位
        case (digit)
            4'h0: led_cx = 8'h03;//分别对应各自的形状
            4'h1: led_cx = 8'h9f;
            4'h2: led_cx = 8'h25;
            4'h3: led_cx = 8'h0d;
            4'h4: led_cx = 8'h99;
            4'h5: led_cx = 8'h49;
            4'h6: led_cx = 8'h41;
            4'h7: led_cx = 8'h1f;
            4'h8: led_cx = 8'h01;
            4'h9: led_cx = 8'h09;
            4'ha: led_cx = 8'h11;
            4'hb: led_cx = 8'hc1;
            4'hc: led_cx = 8'h63;
            4'hd: led_cx = 8'h85;
            4'he: led_cx = 8'h61;
            4'hf: led_cx = 8'h71;
            default: led_cx = 8'hff;
        endcase

        if (rst) begin
            led_en = 8'hff;//都是1
            led_cx = 8'hff;
        end
    end
endmodule
