module calculator(
    input clk,
    input rst,
    input [7:0] rx_data,
    input rx_valid,
    output reg [15:0] result,
    output reg done
);

localparam IDLE = 3'b000;
localparam GETNUM1 = 3'b001;
localparam GETOP = 3'b010;
localparam GETNUM2 = 3'b011;
localparam CALC = 3'b100;

reg [2:0] current_state,next_state;
reg [15:0] number1,number2;
reg [7:0] operator;
wire is_num=(rx_data >= "0" && rx_data <= "9");
wire is_op=(rx_data == "+" || rx_data == "-" || rx_data == "*" || rx_data == "/");
wire is_eq=(rx_data == "=");

always@(posedge clk or posedge rst) begin
    if(rst) current_state <= IDLE;
    else current_state <= next_state;
end

always@(*) begin
    next_state=current_state;
    case(current_state)
        IDLE:if(rx_valid && is_num) next_state = GETNUM1;
        GETNUM1:if(rx_valid && is_op) next_state = GETOP;
        GETOP:if(rx_valid && is_num) next_state = GETNUM2;
        GETNUM2:if(rx_valid && is_eq) next_state = CALC;
        CALC:next_state = IDLE;
        default:next_state = IDLE;
    endcase     
end    

always@(posedge clk or posedge rst) begin
    if(rst) begin
        result <= 0; done<=0; number1<=0; number2<=0; operator<=0;
    end    
    else begin
        done<=0;
        case(current_state)
            IDLE: begin
                number1<=0; number2<=0; operator<=0;
                if(rx_valid && is_num) number1 <= rx_data - "0";
            end    
            GETNUM1:begin
                if(rx_valid && is_num) number1<=number1*10 + (rx_data)- "0";
                else if(rx_valid && is_op) operator<=rx_data;
            end
            GETOP:if(rx_valid && is_num) number2 <= rx_data - "0";
            GETNUM2:if(rx_valid && is_num) number2<=number2*10 + (rx_data)- "0";
            CALC:begin
                case(operator)
                    "+":result<=number1+number2;
                    "-":result<=number1-number2;
                    "*":result<=number1*number2;
                    "/":result<=number1/number2;
                    default:result<=16'h0;
                endcase
                done<=1;
            end  
        endcase       
    end         
end 
endmodule