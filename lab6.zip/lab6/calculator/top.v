module top#(
    parameter integer SCAN_CYCLES = 100000
)(
    input clk,
    input rst,
    input uart_rx,//from PC
    output uart_tx,//to PC
    output[7:0] led_en,
    output[7:0] led_cx
);

wire [7:0] rx_data;
wire rx_valid;
wire [7:0] tx_data;
wire tx_valid;
wire [15:0] result;
wire done;

wire [3:0] d0 = result%10;
wire [3:0] d1 = result%100/10;
wire [3:0] d2 = result%1000/100;
wire [3:0] d3 = result/1000;
wire [31:0] display_data = {16'h0000,d3,d2,d1,d0};

calculator u_calculator(
    .clk(clk),
    .rst(rst),
    .rx_data(rx_data),
    .rx_valid(rx_valid),
    .result(result),
    .done(done)
);

sender u_sender(
    .clk(clk),
    .rst(rst),
    .done(done),
    .result(result),
    .tx_valid(tx_valid),
    .tx_data(tx_data)
);

seg_scan #(.SCAN_CYCLES(SCAN_CYCLES)) u_scan (
        .clk(clk), .rst(rst), .display_data(display_data),
        .led_en(led_en), .led_cx(led_cx)
);

uart_send u(
    .clk(clk),
    .rst(rst),
    .valid(tx_valid),
    .data(tx_data),
    .dout(uart_tx)
);

uart_recv v(
    .clk(clk),   
    .rst(rst),   
    .din(uart_rx), 
    .valid(rx_valid),
    .data(rx_data)  
);

endmodule