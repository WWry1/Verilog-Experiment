module uart_send(
    input        clk,        
    input        rst,        
    input        valid,       // �?1表明接下来的8位data有效，只维持�?个时钟周�?
    input [7:0]  data,        // 待发送的8位数�?
    output reg   dout         // 发�?�信�?
);

localparam IDLE  = 2'b00;   // 空闲态，发�?�高电平
localparam START = 2'b01;   // 起始态，发�?�起始位
localparam DATA  = 2'b10;   // 数据态，�?8位数据位发�?�出�?
localparam STOP  = 2'b11;   // 停止态，发�?�停止位
localparam BAUD  = 14'd10417;

reg[1:0] current_state;
reg[1:0] next_state;
reg[13:0] cnt;
reg[2:0] bit_cnt;
reg[7:0] data_r;
wire tick =(cnt == BAUD);

always @(posedge clk or posedge rst) begin
    if (rst) current_state<= IDLE;
    else current_state<= next_state;
end

always @(*) begin
    next_state = current_state;
     case(current_state)
         IDLE: if(valid) next_state=START;
         START:if(tick) next_state=DATA;
         DATA: if(tick && bit_cnt==7) next_state=STOP;
         STOP: if(cnt==BAUD-14'd50) next_state=IDLE;
         default : next_state=IDLE;
     endcase
end

always @(posedge clk or posedge rst)begin
    if(rst) begin dout<=1;cnt<=0;bit_cnt<=0;data_r<=0; end
    else begin 
        if(current_state == IDLE || tick) cnt<=0;
        else cnt<=cnt+1;
        case(current_state)
            IDLE: begin dout<=1;bit_cnt<=0;if(valid)data_r<=data;end
            START:dout<=0;
            DATA: begin dout<=data_r[bit_cnt];if(tick) bit_cnt<=bit_cnt+1; end
            STOP:dout<=1;
        endcase
    end
end        

endmodule