`timescale 1ns / 1ps

module uart_recv(
    input                   clk,   
    input                   rst,   
    input                   din,   // 串口数据输入

    output reg              valid, // 为1表明输出的数据data有效，只维持一个时钟周期
    output reg [7:0]        data   
);

    localparam    IDLE  = 2'b00;
    localparam    START = 2'b01;
    localparam    DATA  = 2'b10;
    localparam    STOP  = 2'b11;
    localparam    BAUD  = 14'd10417;
    localparam    HALF_BAUD = 14'd5208;

    reg[1:0] current_state;
    reg[1:0] next_state;
    reg[13:0] cnt;
    reg[3:0] bit_cnt;
    reg[7:0] data_r;

    always @(posedge clk or posedge rst) begin
    if (rst) current_state<= IDLE;
    else current_state<= next_state;
    end

    always @(*) begin
        next_state=current_state;
        case(current_state)
            IDLE:next_state=(din==0)?START:IDLE;
            START:if(cnt==HALF_BAUD-1) next_state=(din == 0)?DATA:IDLE;
            DATA:next_state=(cnt==BAUD-1&&bit_cnt==4'd7)?STOP:DATA;
            STOP:next_state=(cnt==BAUD-1)?IDLE:STOP;
            default:next_state=IDLE;
        endcase    
    end    

    always@(posedge clk or posedge rst) begin
        if(rst) begin
            valid<=0;
            cnt<=0;
            bit_cnt<=0;
            data_r<=0;
            data<=0;
        end
        else begin
            valid<=0;
            if(current_state==IDLE||cnt==BAUD-1||(current_state==START&&cnt==HALF_BAUD-1)) cnt<=0;
            else cnt<=cnt+1;
            case(current_state)
                IDLE:bit_cnt<=0;
                DATA:if(cnt==BAUD-1) begin data_r[bit_cnt]<=din;bit_cnt<=bit_cnt+1; end
                STOP:if(cnt==BAUD-1) begin data<=data_r;valid<=1; end
            endcase
        end        
    end     

endmodule