`timescale 1ns / 1ps

// =====================================================================
//  top 模块功能仿真
//  Test 0  复位后的初始状态（数码管只亮低 2 位，计数为 00）
//  Test 1  按 S2（带按键抖动）发送一次；发送过程中再按键应被忽略
//  Test 2  再按一次 S2，累计计数继续增加
//  Test 3  电脑端发送 0~F 共 16 个字符，检查最近 6 个字符、高位熄灭
//  Test 4  发送的同时电脑端也在发送（全双工）
//  Test 5  电脑端波特率有 +2% / -2% 误差时仍能正确接收
//  Tcl Console 里看到 ALL TESTS PASSED 即全部通过（约 70ms 仿真时间）
//  提示：$display 的内容用英文，避免 Windows 控制台中文乱码
// =====================================================================
module top_tb;

    // ===================== 参数 =====================
    localparam DB_CYCLES    = 20;                      // 仿真用消抖周期（上板为 2_000_000）
    localparam SCAN_CYC     = 200;                     // 仿真用扫描周期（上板为 100_000）
    localparam HOLD_CLK     = 5 * DB_CYCLES;           // 按键保持 / 释放的时钟数
    localparam LIT_WINDOW   = 8 * SCAN_CYC * 4;        // 观察数码管亮灭的时钟数
    localparam real BIT_T   = 1000000000.0 / 9600.0;   // 9600 波特率下一位的时间 (ns)
    localparam KEY_PRESSED  = 1'b1;                    // S2 按下时 key 的电平，板子相反就改成 1'b0
    localparam KEY_RELEASED = ~KEY_PRESSED;

    // ===================== 信号 =====================
    reg         clk = 1'b0;
    reg         rst = 1'b1;
    reg         key = KEY_RELEASED;
    reg         din = 1'b1;
    wire        dout;
    wire [7:0]  led_en;
    wire [7:0]  led_cx;

    integer     error_cnt = 0;
    reg         rst_done  = 1'b0;
    real        bit_scale = 1.0;    // 电脑端位宽缩放，用来模拟波特率误差

    reg [8*12-1:0] TX_STR;          // 期望 FPGA 发出的字符串
    reg [8*16-1:0] RX_STR;          // 电脑端要发给 FPGA 的字符
    initial begin
        TX_STR = "132025310450";
        RX_STR = "0123456789ABCDEF";
    end

    always #5 clk = ~clk;           // 100MHz

    top #(.DEBOUNCE_CYCLES(DB_CYCLES), .SCAN_CYCLES(SCAN_CYC)) uut (
        .clk(clk), .rst(rst), .key(key), .din(din),
        .dout(dout), .led_en(led_en), .led_cx(led_cx)
    );

    // ===================== 发送监测：按 9600 波特率解析 dout =====================
    integer     tx_count = 0;
    reg [7:0]   tx_log [0:63];
    time        tx_t   [0:63];      // 每个字符起始位下降沿的时刻
    reg [7:0]   mon_byte;
    integer     mi;

    initial begin
        wait (rst_done);
        forever begin
            @(negedge dout);
            tx_t[tx_count] = $time;
            #(BIT_T / 2.0);                         // 起始位中点
            if (dout !== 1'b0) begin
                $display("[ERROR] %t: dout start bit is not 0", $time);
                error_cnt = error_cnt + 1;
            end
            for (mi = 0; mi < 8; mi = mi + 1) begin // 低位先发
                #(BIT_T);
                mon_byte[mi] = dout;
            end
            #(BIT_T);                               // 停止位中点
            if (dout !== 1'b1) begin
                $display("[ERROR] %t: dout stop bit is not 1", $time);
                error_cnt = error_cnt + 1;
            end
            tx_log[tx_count] = mon_byte;
            tx_count = tx_count + 1;
        end
    end

    // ===================== 接收侧监测：rx_valid 必须只有一个周期 =====================
    reg         rv_d = 1'b0;
    integer     rx_valid_cnt = 0;

    always @(posedge clk) begin
        rv_d <= uut.rx_valid;
        if (rst_done && uut.rx_valid === 1'b1) begin
            rx_valid_cnt = rx_valid_cnt + 1;
            if (rv_d === 1'b1) begin
                $display("[ERROR] %t: rx_valid lasts more than one cycle", $time);
                error_cnt = error_cnt + 1;
            end
        end
    end

    // ===================== 数码管监测 =====================
    // 1) 任何时刻都不能点亮 digit_en 为 0 的位（led_en 低电平有效）
    integer led_err = 0;
    always @(posedge clk) begin
        if (rst_done && (((~led_en) & (~uut.digit_en)) !== 8'b0)) begin
            if (led_err == 0) error_cnt = error_cnt + 1;
            if (led_err < 3)
                $display("[ERROR] %t: led_en=%b lights a disabled digit (digit_en=%b)",
                         $time, led_en, uut.digit_en);
            led_err = led_err + 1;
        end
    end

    // 2) 统计一段时间内哪些位被点亮过
    reg [7:0]   lit_seen;
    reg         lit_clear = 1'b0;
    always @(posedge clk) begin
        if (lit_clear) lit_seen <= 8'h00;
        else           lit_seen <= lit_seen | ~led_en;
    end

    task check_display(input [7:0] expect_en);
        begin
            @(negedge clk) lit_clear = 1'b1;
            @(negedge clk) lit_clear = 1'b0;
            repeat (LIT_WINDOW) @(posedge clk);
            #1;
            if (lit_seen !== expect_en) begin
                $display("[ERROR] lit digits %b, expected %b", lit_seen, expect_en);
                error_cnt = error_cnt + 1;
            end else
                $display("[PASS ] lit digits = %b", lit_seen);
        end
    endtask

    // ===================== 按键 =====================
    task press_key;                 // 干净的按下 + 释放
        begin
            key = KEY_PRESSED;
            repeat (HOLD_CLK) @(posedge clk);
            key = KEY_RELEASED;
            repeat (HOLD_CLK) @(posedge clk);
        end
    endtask

    task press_key_bouncy;          // 按下和释放时都带抖动（每段都远小于消抖时间）
        begin
            key = KEY_PRESSED;  repeat (3) @(posedge clk);
            key = KEY_RELEASED; repeat (4) @(posedge clk);
            key = KEY_PRESSED;  repeat (5) @(posedge clk);
            key = KEY_RELEASED; repeat (3) @(posedge clk);
            key = KEY_PRESSED;  repeat (HOLD_CLK) @(posedge clk);
            key = KEY_RELEASED; repeat (4) @(posedge clk);
            key = KEY_PRESSED;  repeat (3) @(posedge clk);
            key = KEY_RELEASED; repeat (HOLD_CLK) @(posedge clk);
        end
    endtask

    // ===================== 发送检查 =====================
    task wait_tx_count(input integer target);
        integer t;
        begin
            t = 0;
            while (tx_count < target && t < 4000) begin   // 最多等 40ms
                #10000;
                t = t + 1;
            end
            if (tx_count < target) begin
                $display("[ERROR] timeout: got only %0d/%0d chars", tx_count, target);
                error_cnt = error_cnt + 1;
            end
        end
    endtask

    task check_tx_string(input integer base);
        integer k;
        reg [7:0] exp_c;
        time dt, dt_min, dt_max;
        reg ok;
        begin
            ok = 1'b1;
            dt_min = 64'hFFFF_FFFF_FFFF_FFFF;
            dt_max = 0;
            for (k = 0; k < 12; k = k + 1) begin
                exp_c = TX_STR[8*(11-k) +: 8];
                if (tx_log[base + k] !== exp_c) begin
                    $display("[ERROR] char %0d: expected %c (%h), got %c (%h)",
                             k, exp_c, exp_c, tx_log[base + k], tx_log[base + k]);
                    error_cnt = error_cnt + 1;
                    ok = 1'b0;
                end
                if (k > 0) begin
                    dt = tx_t[base + k] - tx_t[base + k - 1];
                    if (dt < dt_min) dt_min = dt;
                    if (dt > dt_max) dt_max = dt;
                end
            end
            // 相邻字符起始位间隔：必须大于一帧时间（约 1.042ms），且不大于 0.01s
            if (dt_min < 1050000 || dt_max > 10000000) begin
                $display("[ERROR] bad char interval: min %0d ns, max %0d ns", dt_min, dt_max);
                error_cnt = error_cnt + 1;
                ok = 1'b0;
            end
            if (ok)
                $display("[PASS ] sent \"%0s\" correctly, char interval %0d ~ %0d ns",
                         TX_STR, dt_min, dt_max);
        end
    endtask

    // ===================== 电脑端发送（给 din 灌 UART 帧） =====================
    reg [23:0]  exp_chars = 24'd0;      // 期望的 rx_chars（参考模型）
    reg [5:0]   exp_mask  = 6'd0;       // 期望的 rx_mask
    integer     rx_sent   = 0;

    function [3:0] hex_val(input [7:0] ch);
        begin
            if (ch >= "0" && ch <= "9") hex_val = ch - "0";
            else                        hex_val = ch - "A" + 8'd10;
        end
    endfunction

    task uart_drive_byte(input [7:0] b);
        integer n;
        begin
            din = 1'b0;  #(BIT_T * bit_scale);                  // 起始位
            for (n = 0; n < 8; n = n + 1) begin                 // 低位先发
                din = b[n];
                #(BIT_T * bit_scale);
            end
            din = 1'b1;  #(BIT_T * bit_scale);                  // 停止位
        end
    endtask

    // 发送一个字符，帧结束后检查 rx_chars / rx_mask，然后再空闲 gap_bits 位
    task rx_and_check(input [7:0] ch, input integer gap_bits);
        begin
            uart_drive_byte(ch);
            exp_chars = {exp_chars[19:0], hex_val(ch)};
            exp_mask  = {exp_mask[4:0], 1'b1};
            rx_sent   = rx_sent + 1;
            if (uut.rx_chars !== exp_chars || uut.rx_mask !== exp_mask) begin
                $display("[ERROR] after sending %c: rx_chars=%h (exp %h)  rx_mask=%b (exp %b)",
                         ch, uut.rx_chars, exp_chars, uut.rx_mask, exp_mask);
                error_cnt = error_cnt + 1;
            end
            repeat (gap_bits) #(BIT_T * bit_scale);
        end
    endtask

    // ===================== 主流程 =====================
    integer tx_base;
    integer j;

    initial begin
        $timeformat(-9, 0, " ns", 0);

        // 复位（高有效）
        repeat (10) @(posedge clk);
        #1 rst = 1'b0;
        repeat (5) @(posedge clk);
        rst_done = 1'b1;

        // ---------------------------------------------------------
        $display("---- Test 0: initial state after reset ----");
        if (dout !== 1'b1 || uut.rx_mask !== 6'b0 || uut.rx_chars !== 24'd0 ||
            uut.tens !== 4'd0 || uut.ones !== 4'd0) begin
            $display("[ERROR] bad initial state: dout=%b rx_mask=%b rx_chars=%h count=%0d%0d",
                     dout, uut.rx_mask, uut.rx_chars, uut.tens, uut.ones);
            error_cnt = error_cnt + 1;
        end else
            $display("[PASS ] dout=1, rx registers cleared, count = 00");
        check_display(8'b0000_0011);        // 只有低 2 位（计数）亮

        // ---------------------------------------------------------
        $display("---- Test 1: press S2 (with bounce) once; a press during sending is ignored ----");
        tx_base = tx_count;
        press_key_bouncy;
        #5000000;                           // 5ms 后字符串还在发送中
        press_key;                          // 发送过程中再次按键
        wait_tx_count(tx_base + 12);
        #2000000;                           // 再等 2ms，确认没有多发
        if (tx_count !== tx_base + 12) begin
            $display("[ERROR] one press sent %0d chars, expected 12", tx_count - tx_base);
            error_cnt = error_cnt + 1;
        end else
            $display("[PASS ] exactly 12 chars per press (bounce filtered, press while sending ignored)");
        check_tx_string(tx_base);
        if (uut.tens !== 4'd1 || uut.ones !== 4'd2) begin
            $display("[ERROR] count shows %0d%0d, expected 12", uut.tens, uut.ones);
            error_cnt = error_cnt + 1;
        end else
            $display("[PASS ] sent-char count = 12");

        // ---------------------------------------------------------
        $display("---- Test 2: press S2 again ----");
        tx_base = tx_count;
        press_key;
        wait_tx_count(tx_base + 12);
        #2000000;
        if (tx_count !== tx_base + 12) begin
            $display("[ERROR] second press sent %0d chars, expected 12", tx_count - tx_base);
            error_cnt = error_cnt + 1;
        end
        check_tx_string(tx_base);
        if (uut.tens !== 4'd2 || uut.ones !== 4'd4) begin
            $display("[ERROR] count shows %0d%0d, expected 24", uut.tens, uut.ones);
            error_cnt = error_cnt + 1;
        end else
            $display("[PASS ] sent-char count = 24");

        // ---------------------------------------------------------
        $display("---- Test 3: receive 0~F (16 chars, idle 0/1/2 bits between frames) ----");
        for (j = 0; j < 16; j = j + 1) begin
            rx_and_check(RX_STR[8*(15-j) +: 8], j % 3);
            if (j == 0 || j == 2 || j == 5 || j == 15)
                check_display({exp_mask, 2'b11});
        end
        if (rx_valid_cnt !== rx_sent) begin
            $display("[ERROR] sent %0d chars, rx_valid pulsed %0d times", rx_sent, rx_valid_cnt);
            error_cnt = error_cnt + 1;
        end else
            $display("[PASS ] all %0d chars received, rx_chars=%h (latest 6)", rx_sent, uut.rx_chars);

        // ---------------------------------------------------------
        $display("---- Test 4: send and receive at the same time ----");
        tx_base = tx_count;
        fork
            begin                           // 发送线程
                press_key;
                wait_tx_count(tx_base + 12);
            end
            begin                           // 接收线程
                #2000000;
                for (j = 0; j < 6; j = j + 1)
                    rx_and_check("A" + j, 0);
            end
        join
        #2000000;
        if (tx_count !== tx_base + 12) begin
            $display("[ERROR] sent %0d chars while receiving, expected 12", tx_count - tx_base);
            error_cnt = error_cnt + 1;
        end
        check_tx_string(tx_base);
        if (uut.tens !== 4'd3 || uut.ones !== 4'd6) begin
            $display("[ERROR] count shows %0d%0d, expected 36", uut.tens, uut.ones);
            error_cnt = error_cnt + 1;
        end else
            $display("[PASS ] sent-char count = 36");
        if (rx_valid_cnt !== rx_sent) begin
            $display("[ERROR] sent %0d chars, rx_valid pulsed %0d times", rx_sent, rx_valid_cnt);
            error_cnt = error_cnt + 1;
        end else
            $display("[PASS ] receiving is not disturbed by sending, rx_chars=%h", uut.rx_chars);

        // ---------------------------------------------------------
        $display("---- Test 5: host baud rate off by +2%% / -2%% ----");
        bit_scale = 1.02;
        for (j = 0; j < 6; j = j + 1)
            rx_and_check(RX_STR[8*(15-j) +: 8], 1);
        bit_scale = 0.98;
        for (j = 6; j < 12; j = j + 1)
            rx_and_check(RX_STR[8*(15-j) +: 8], 1);
        bit_scale = 1.0;
        if (rx_valid_cnt !== rx_sent) begin
            $display("[ERROR] sent %0d chars, rx_valid pulsed %0d times", rx_sent, rx_valid_cnt);
            error_cnt = error_cnt + 1;
        end else if (error_cnt == 0)
            $display("[PASS ] receive tolerates +-2%% baud error, rx_chars=%h", uut.rx_chars);

        // ---------------------------------------------------------
        if (error_cnt == 0)
            $display("===== ALL TESTS PASSED =====");
        else
            $display("===== %0d ERROR(S) FOUND =====", error_cnt);
        $finish;
    end

    // 看门狗：防止仿真卡死
    initial begin
        #200000000;
        $display("[ERROR] simulation timeout (200 ms)");
        $finish;
    end

endmodule
