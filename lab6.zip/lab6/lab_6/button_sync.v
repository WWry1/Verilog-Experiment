`timescale 1ns / 1ps
// 按键确认，两级寄存器同步异步输入，再用一个历史寄存器检测上升沿。
module button_sync (
    input wire clk,
    input wire rst,
    input wire key_in,
    output wire key_sync,//经过两次寄存器后的电平
    output wire rise_pulse//脉冲
);
reg sync_ff1;
reg sync_ff2;
reg sync_old;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            sync_ff1 <= 1'b0;
            sync_ff2 <= 1'b0;
            sync_old <= 1'b0;
        end else begin
            sync_ff1 <= key_in;
            sync_ff2 <= sync_ff1;//往后延迟了两个时钟沿
            sync_old <= sync_ff2;
        end
    end

    assign key_sync = sync_ff2;
    assign rise_pulse = sync_ff2 & ~sync_old;//只有一个时钟周期使得sync_ff2=1,sync_old=0
endmodule
