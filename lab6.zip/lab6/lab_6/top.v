module top #(
    parameter integer DEBOUNCE_CYCLES = 2_000_000,
    parameter integer SCAN_CYCLES = 100_000
)(
    input clk,
    input rst,
    input key,
    input din,
    output dout,
    output wire [7:0] led_en,
    output wire [7:0] led_cx
);
parameter LEN =12 ;
parameter GAP_CNT=120000-1;
localparam WAIT=2'b00;
localparam SEND=2'b01;
localparam GAP=2'b10;

reg tx_valid;
reg[7:0] tx_data;
wire rx_valid;
wire[7:0] rx_data;
reg[1:0]current_state,next_state;
reg[24:0]cnt;
reg[3:0]idx;
wire key_sync;
wire key_press,key_pulse;
wire key_stable;
wire [3:0]tens,ones;
wire [31:0] display_data;
wire is_digit = (rx_data >= "0") && (rx_data <= "9");
wire is_upper = (rx_data >= "A") && (rx_data <= "F");
wire is_lower = (rx_data >= "a") && (rx_data <= "f");
wire is_hex   = is_digit || is_upper || is_lower;

wire [3:0] rx_val = is_digit ? (rx_data - 8'h30) :
                    is_upper ? (rx_data - 8'h37) :
                    is_lower ? (rx_data - 8'h57) : 4'h0;
reg  [23:0] rx_chars;
reg  [5:0] rx_mask;
wire [7:0] led_en_raw;
wire [7:0] digit_en = {rx_mask,2'b11};
reg rx_valid_d;
wire rx_pulse = rx_valid && !rx_valid_d;


 button_sync u_sync_s2 (
        .clk(clk), .rst(rst), .key_in(key),
        .key_sync(key_sync), .rise_pulse(key_pulse)
 );
 key_debounce #(.DEBOUNCE_CYCLES(DEBOUNCE_CYCLES)) u_debounce_s2 (
        .clk(clk), .rst(rst), .key_sync(key_sync),
        .key_stable(key_stable), .press_pulse(key_press)
);
 decimal_counter u_count (
        .clk(clk), .rst(rst), .count_en(tx_valid),
        .tens(tens), .ones(ones)
    );

always @(posedge clk or posedge rst) begin
    if (rst)
        rx_valid_d <= 1'b0;
    else
        rx_valid_d <= rx_valid;
end


always @(*) 
     case(idx)
     0:tx_data="1";
     1:tx_data="3";
     2:tx_data="2";
     3:tx_data="0";
     4:tx_data="2";
     5:tx_data="5";
     6:tx_data="3";
     7:tx_data="1";
     8:tx_data="0";
     9:tx_data="4";
     10:tx_data="5";
     11:tx_data="0";
     default:tx_data=8'h00;
     endcase

always @(posedge clk or posedge rst) begin
    if(rst) current_state <= WAIT;
    else current_state <= next_state;
end

always @(*) begin
    next_state = current_state;
   case(current_state)
       WAIT:if(key_press)  next_state = SEND;
       SEND: next_state = GAP;
       GAP:if(cnt==GAP_CNT) begin
        if(idx==LEN-1)  next_state = WAIT;
        else next_state = SEND;
       end
       default:next_state = WAIT;
   endcase
end

always @(posedge clk or posedge rst) begin
    if(rst) begin 
        idx <= 4'b0;
        tx_valid <= 1'b0;
        cnt <= 25'b0;
    end
    else begin
        case(current_state)
            WAIT:begin
                tx_valid<=0;
                idx<=0;
                cnt<=0;
            end
            SEND:begin
                tx_valid<=1;
                cnt <=0;
            end
            GAP:begin
                tx_valid<=0;
                if(cnt==GAP_CNT) begin 
                    cnt<=0;
                    idx <= idx+1;
                end    
                else cnt<=cnt+1;
            end
            default: begin
                tx_valid <= 1'b0;
                cnt   <= 25'd0;
                idx   <= 4'd0;
            end
        endcase
    end
end

always @(posedge clk or posedge rst) begin
    if (rst) begin
        rx_chars <= 24'b0;
        rx_mask  <= 6'b0;
    end else if (rx_pulse && is_hex) begin
        rx_chars <= {rx_chars[19:0], rx_val};
        rx_mask  <= {rx_mask[4:0], 1'b1};
    end
end


assign display_data = {rx_chars,tens,ones};

seg_scan #(.SCAN_CYCLES(SCAN_CYCLES)) u_scan (
        .clk(clk), .rst(rst), .display_data(display_data),
        .led_en(led_en_raw), .led_cx(led_cx)
);

assign led_en = led_en_raw | ~digit_en;

uart_send u(
    .clk(clk),
    .rst(rst),
    .valid(tx_valid),
    .data(tx_data),
    .dout(dout)
);

uart_recv v(
    .clk(clk),   
    .rst(rst),   
    .din(din), 
    .valid(rx_valid),
    .data(rx_data)  
);
endmodule