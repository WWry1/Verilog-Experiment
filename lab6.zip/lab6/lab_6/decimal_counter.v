`timescale 1ns/1ps

module decimal_counter(
    input wire clk,
    input wire rst,
    input wire count_en,
    output reg [3:0] tens,
    output reg [3:0] ones
);
always @(posedge clk or posedge rst)begin
    if(rst) begin
        tens<=4'd0;
        ones<=4'd0;
    end
    else if(count_en) begin
        if(ones==4'd9) begin
            ones<=4'd0;
            if(tens==4'd9) tens<=4'd0;
            else tens<=tens+4'd1;
            end
        else ones<=ones+4'd1;    
    end
end
endmodule        