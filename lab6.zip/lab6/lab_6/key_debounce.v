`timescale 1ns / 1ps
// 输入已经同步。按下、释放都必须连续稳定 DEBOUNCE_CYCLES 个时钟。
module key_debounce #(
    parameter integer DEBOUNCE_CYCLES = 2_000_000
) (
    input wire clk,
    input wire rst,
    input wire key_sync,
    output reg key_stable,
    output wire press_pulse
);
    localparam integer CNT_LAST_VALUE = DEBOUNCE_CYCLES - 1;
    localparam [16:0] CNT_LAST = CNT_LAST_VALUE[16:0];
    reg [16:0] stable_cnt;
    reg key_old;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            stable_cnt <= {17'b0};
            key_stable <= 1'b0;
        end else if (key_sync == key_stable) begin
            stable_cnt <= {17'b0};
        end else if (stable_cnt == CNT_LAST) begin
            stable_cnt <= {17'b0};
            key_stable <= key_sync;
        end else begin
            stable_cnt <= stable_cnt + 1'b1;
        end
    end

    always @(posedge clk or posedge rst) begin
        if (rst)
            key_old <= 1'b0;
        else
            key_old <= key_stable;
    end

    assign press_pulse = key_stable & ~key_old;
endmodule
