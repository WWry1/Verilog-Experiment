`timescale 1ns / 1ps
module tb_led_ctrl_unit;
    reg clk = 1'b0;
    reg rst = 1'b0;
    reg key_s2 = 1'b0;
    reg key_s3 = 1'b0;
    reg mode_sel = 1'b1;
    wire [7:0] led_en, led_cx;
    integer i, j;
    reg [7:0] saved_auto;
    reg [6:0] saved_tick;
    reg [7:0] saved_raw, saved_clean;
    reg [7:0] expected_cx;
    reg [7:0] seen_digits;

    // 只覆盖仿真实例参数，上板时保持顶层默认参数。
    led_ctrl_unit #(
        .SCAN_CYCLES(10),
        .DEBOUNCE_CYCLES(10),
        .TICK_CYCLES(100)
    ) uut (
        .clk(clk), .rst(rst), .key_s2(key_s2), .key_s3(key_s3),
        .mode_sel(mode_sel), .led_en(led_en), .led_cx(led_cx)
    );

    always #5 clk = ~clk;

    // 在下降沿之后改输入，避免与DUT上升沿采样发生竞争。
    task cycles;
        input integer n;
        begin
            repeat (n) @(negedge clk);
            #1;
        end
    endtask

    task reset_all;
        begin
            rst = 1'b1;
            key_s2 = 1'b0;
            key_s3 = 1'b0;
            cycles(5);
            rst = 1'b0;
            cycles(5);
        end
    endtask

    task clean_s3_press;
        begin
            key_s3 = 1'b1;
            cycles(20);
            key_s3 = 1'b0;
            cycles(20);
        end
    endtask

    // 短暂按下/松开均为4拍，小于10拍消抖窗口。
    task bounced_s3_press;
        begin
            key_s3 = 1'b1; cycles(4);
            key_s3 = 1'b0; cycles(4);
            key_s3 = 1'b1; cycles(4);
            key_s3 = 1'b0; cycles(4);
            key_s3 = 1'b1; cycles(25);
            key_s3 = 1'b0; cycles(4);
            key_s3 = 1'b1; cycles(4);
            key_s3 = 1'b0; cycles(25);
        end
    endtask

    task bounced_s2_press;
        begin
            key_s2 = 1'b1; cycles(4);
            key_s2 = 1'b0; cycles(4);
            key_s2 = 1'b1; cycles(4);
            key_s2 = 1'b0; cycles(4);
            key_s2 = 1'b1; cycles(25);
            key_s2 = 1'b0; cycles(4);
            key_s2 = 1'b1; cycles(4);
            key_s2 = 1'b0; cycles(25);
        end
    endtask

    initial begin
        $dumpfile("lab4_seg.vcd");
        $dumpvars(0, tb_led_ctrl_unit);
        reset_all;

        // 1. 学号、8位扫描顺序、每位段码。
        if (uut.display_data !== 32'h25310450)
            $fatal(1, "Student ID mismatch");
        seen_digits = 8'h00;
        for (i = 0; i < 80; i = i + 1) begin
            case (uut.u_scan.scan_index)
                3'd0: expected_cx = 8'h03; // 最右0
                3'd1: expected_cx = 8'h49; // 5
                3'd2: expected_cx = 8'h99; // 4
                3'd3: expected_cx = 8'h03; // 0
                3'd4: expected_cx = 8'h9f; // 1
                3'd5: expected_cx = 8'h0d; // 3
                3'd6: expected_cx = 8'h49; // 5
                3'd7: expected_cx = 8'h25; // 最左2
                default: expected_cx = 8'hff;
            endcase
            if (led_cx !== expected_cx ||
                led_en !== ~(8'b1 << uut.u_scan.scan_index))
                $fatal(1, "Scan or segment mismatch");
            seen_digits[uut.u_scan.scan_index] = 1'b1;
            cycles(1);
        end
        if (seen_digits !== 8'hff)
            $fatal(1, "Not all digits were scanned");
        $display("PASS: student ID and all eight scan positions");

        // 2. 两次抖动按键：消抖后计2次，未消抖计8次。
        mode_sel = 1'b0;
        cycles(5);
        bounced_s3_press;
        bounced_s3_press;
        if ({uut.raw_tens, uut.raw_ones} !== 8'h08 ||
            {uut.clean_tens, uut.clean_ones} !== 8'h02)
            $fatal(1, "Bounce comparison mismatch");
        if (uut.display_data[31:8] !== 24'h500802)
            $fatal(1, "Mixed display layout mismatch");
        $display("PASS: two bounced presses, raw=08 clean=02");

        // 长按不会一直计数。
        key_s3 = 1'b1;
        cycles(30);
        saved_raw = {uut.raw_tens, uut.raw_ones};
        saved_clean = {uut.clean_tens, uut.clean_ones};
        cycles(200);
        if ({uut.raw_tens, uut.raw_ones} !== saved_raw ||
            {uut.clean_tens, uut.clean_ones} !== saved_clean)
            $fatal(1, "Long press counted repeatedly");
        key_s3 = 1'b0;
        cycles(20);
        $display("PASS: holding S3 counts only once");

        // 3. S2抖动仅切换一次，暂停保留显示值和分频计数。
        bounced_s2_press;
        if (uut.running !== 1'b0) $fatal(1, "Pause failed");
        saved_auto = {uut.auto_tens, uut.auto_ones};
        saved_tick = uut.tick_cnt;
        cycles(300);
        if ({uut.auto_tens, uut.auto_ones} !== saved_auto ||
            uut.tick_cnt !== saved_tick)
            $fatal(1, "Counter advanced while paused");
        // S2长按不会不停切换。
        key_s2 = 1'b1;
        cycles(20);
        if (uut.running !== 1'b1) $fatal(1, "Resume failed");
        cycles(200);
        if (uut.running !== 1'b1) $fatal(1, "S2 hold toggled repeatedly");
        key_s2 = 1'b0;
        cycles(20);
        $display("PASS: bounced S2 pause/resume and hold");

        // 4. 精确检查每100拍加1，含09->10、19->20、20->00。
        rst = 1'b1; cycles(5); rst = 1'b0;
        for (i = 0; i < 21; i = i + 1) begin
            cycles(99);
            if ((10 * {28'd0, uut.auto_tens} + {28'd0, uut.auto_ones}) != i)
                $fatal(1, "Auto counter advanced early");
            cycles(1);
            if (i == 20) j = 0; else j = i + 1;
            if ((10 * {28'd0, uut.auto_tens} + {28'd0, uut.auto_ones}) != j)
                $fatal(1, "Auto counter interval or wrap mismatch");
        end
        $display("PASS: exact interval and 00..20..00 sequence");

        // 5. 两组十进制计数均能从99回到00。
        reset_all;
        for (i = 0; i < 100; i = i + 1)
            clean_s3_press;
        if ({uut.raw_tens, uut.raw_ones} !== 8'h00 ||
            {uut.clean_tens, uut.clean_ones} !== 8'h00)
            $fatal(1, "00..99 wrap failed");
        $display("PASS: both key counters wrap at 99");

        // 6. 切换模式只改变显示，所有计数在后台继续运行。
        mode_sel = 1'b1; cycles(5);
        clean_s3_press;
        if (uut.display_data !== 32'h25310450)
            $fatal(1, "Fixed display failed after mode switch");
        mode_sel = 1'b0; cycles(5);
        if (uut.display_data[31:8] !== 24'h500101)
            $fatal(1, "Background counters lost on mode switch");

        // 7. 不等待时钟边沿，直接检查高有效异步复位。
        #2 rst = 1'b1;
        #1;
        if (uut.tick_cnt !== 0 || uut.running !== 1'b1 ||
            {uut.raw_tens, uut.raw_ones, uut.clean_tens,
             uut.clean_ones, uut.auto_tens, uut.auto_ones} !== 24'h0 ||
            led_en !== 8'hff || led_cx !== 8'hff)
            $fatal(1, "Asynchronous reset failed");
        $display("PASS: mode switch and asynchronous reset");
        $display("ALL TESTS PASSED");
        cycles(5);
        $finish;
    end

    initial begin
        #200000;
        $fatal(1, "Simulation timeout");
    end
endmodule
