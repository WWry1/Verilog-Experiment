`timescale 1ns / 1ps
// 实验4，学号后8位25310450；Minisys，100MHz。
// S1：高有效异步复位；S2：暂停/继续；S3：两组按键计数。
// SW0=1显示学号；SW0=0显示 50 | 未消抖次数 | 消抖次数 | 00~20。
module led_ctrl_unit #(
    parameter [31:0] STUDENT_ID = 32'h25310450,
    parameter integer SCAN_CYCLES = 100_000,
    parameter integer DEBOUNCE_CYCLES = 2_000_000,
    parameter integer TICK_CYCLES = 10_000_000
) (
    input wire clk,
    input wire rst,
    input wire key_s2,
    input wire key_s3,
    input wire mode_sel,
    output wire [7:0] led_en,
    output wire [7:0] led_cx
);
    wire s2_sync, s3_sync, mode_sync;
    wire s3_raw_pulse, s2_press, s3_press;
    wire s2_stable, s3_stable;
    wire [3:0] raw_tens, raw_ones, clean_tens, clean_ones;
    wire [31:0] display_data;
    reg running;
    reg [3:0] auto_tens, auto_ones;
    localparam integer TICK_WIDTH = (TICK_CYCLES > 1)
                                   ? $clog2(TICK_CYCLES) : 1;
    localparam integer TICK_LAST_VALUE = TICK_CYCLES - 1;
    localparam [TICK_WIDTH-1:0] TICK_LAST = TICK_LAST_VALUE[TICK_WIDTH-1:0];
    reg [TICK_WIDTH-1:0] tick_cnt;

    button_sync u_sync_s2 (
        .clk(clk), .rst(rst), .key_in(key_s2),
        .key_sync(s2_sync), .rise_pulse()
    );
    button_sync u_sync_s3 (
        .clk(clk), .rst(rst), .key_in(key_s3),
        .key_sync(s3_sync), .rise_pulse(s3_raw_pulse)
    );
    button_sync u_sync_mode (
        .clk(clk), .rst(rst), .key_in(mode_sel),
        .key_sync(mode_sync), .rise_pulse()
    );
    key_debounce #(.DEBOUNCE_CYCLES(DEBOUNCE_CYCLES)) u_debounce_s2 (
        .clk(clk), .rst(rst), .key_sync(s2_sync),
        .key_stable(s2_stable), .press_pulse(s2_press)
    );
    key_debounce #(.DEBOUNCE_CYCLES(DEBOUNCE_CYCLES)) u_debounce_s3 (
        .clk(clk), .rst(rst), .key_sync(s3_sync),
        .key_stable(s3_stable), .press_pulse(s3_press)
    );
    decimal_counter u_count_raw (
        .clk(clk), .rst(rst), .count_en(s3_raw_pulse),
        .tens(raw_tens), .ones(raw_ones)
    );
    decimal_counter u_count_clean (
        .clk(clk), .rst(rst), .count_en(s3_press),
        .tens(clean_tens), .ones(clean_ones)
    );

    always @(posedge clk or posedge rst) begin
        if (rst)
            running <= 1'b1;
        else if (s2_press)
            running <= ~running;
    end

    // 暂停保留小于0.1秒的已计时间；S2按下事件优先，事件当拍不计时。
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            tick_cnt <= {TICK_WIDTH{1'b0}};
            auto_tens <= 4'd0;
            auto_ones <= 4'd0;
        end else if (running && !s2_press) begin
            if (tick_cnt == TICK_LAST) begin
                tick_cnt <= {TICK_WIDTH{1'b0}};
                if (auto_tens == 4'd2 && auto_ones == 4'd0) begin
                    auto_tens <= 4'd0;
                    auto_ones <= 4'd0;
                end else if (auto_ones == 4'd9) begin
                    auto_ones <= 4'd0;
                    auto_tens <= auto_tens + 4'd1;
                end else begin
                    auto_ones <= auto_ones + 4'd1;
                end
            end else begin
                tick_cnt <= tick_cnt + 1'b1;
            end
        end
    end

    // 学号每个十进制数字占4位；32'h表示波形中可直接读出的BCD排布。
    assign display_data = mode_sync ? STUDENT_ID :
        {STUDENT_ID[7:0], raw_tens, raw_ones,
         clean_tens, clean_ones, auto_tens, auto_ones};

    seg_scan #(.SCAN_CYCLES(SCAN_CYCLES)) u_scan (
        .clk(clk), .rst(rst), .display_data(display_data),
        .led_en(led_en), .led_cx(led_cx)
    );
endmodule
