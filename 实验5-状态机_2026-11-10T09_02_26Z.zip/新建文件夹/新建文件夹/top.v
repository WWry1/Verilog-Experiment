module top(
    input clk,
    input rst,
    output dout
);
parameter LEN =15 ;
parameter WAIT_CNT=25000000-1;
parameter GAP_CNT=120000-1;
localparam WAIT=2'b00;
localparam SEND=2'b01;
localparam GAP=2'b10;

reg valid;
reg[7:0]data;
reg[1:0]current_state,next_state;
reg[24:0]cnt;
reg[3:0]idx;

always @(*) 
     case(idx)
     0:data="h";
     1:data="i";
     2:data="t";
     3:data="s";
     4:data="z";
     5:data="2";
     6:data="0";
     7:data="2";
     8:data="5";
     9:data="3";
     10:data="1";
     11:data="0";
     12:data="4";
     13:data="5";
     14:data="0";
     default:data=8'h00;
     endcase

always @(posedge clk or posedge rst) begin
    if(rst) current_state <= WAIT;
    else current_state <= next_state;
end

always @(*) begin
    next_state = current_state;
   case(current_state)
       WAIT:if(cnt==WAIT_CNT)  next_state = SEND;
       SEND: next_state = GAP;
       GAP:if(cnt==GAP_CNT) begin
        if(idx==LEN-1)  next_state = WAIT;
        else next_state = SEND;
       end
       default:next_state = WAIT;
   endcase
end

always @(posedge clk or posedge rst) begin
    if(rst) begin 
        idx <= 4'b0;
        valid <= 1'b0;
        cnt <= 25'b0;
    end
    else begin
        case(current_state)
            WAIT:begin
                valid<=0;
                idx<=0;
                if(cnt==WAIT_CNT) cnt<=0;
                else cnt<=cnt+1;
            end
            SEND:begin
                valid<=1;
                cnt <=0;
            end
            GAP:begin
                valid<=0;
                if(cnt==GAP_CNT) begin 
                    cnt<=0;
                    idx <= idx+1;
                end    
                else cnt<=cnt+1;
            end
            default: begin
                valid <= 1'b0;
                cnt   <= 25'd0;
                idx   <= 4'd0;
            end
        endcase
    end
end

uart_send u(
    .clk(clk),
    .rst(rst),
    .valid(valid),
    .data(data),
    .dout(dout)
);
endmodule