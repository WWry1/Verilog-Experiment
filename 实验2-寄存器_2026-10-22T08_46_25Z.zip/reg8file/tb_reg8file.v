`timescale 1ns / 1ps

module tb_reg8file;

    reg        clk;
    reg        clr;
    reg        en;
    reg  [7:0] d;
    reg  [2:0] wsel;
    reg  [2:0] rsel;
    wire [7:0] q;

    reg8file uut (
        .clk  (clk),
        .clr  (clr),
        .en   (en),
        .d    (d),
        .wsel (wsel),
        .rsel (rsel),
        .q    (q)
    );

    initial clk = 1'b0;
    always #5 clk = ~clk;

    initial begin
        clr  = 0;
        en   = 0;
        d    = 8'h00;
        wsel = 0;
        rsel = 0;

        #2 clr = 1;
        #6 clr = 0;

        #2;
        en   = 1;
        wsel = 0;
        d    = 8'hAA;

        #10;
        wsel = 1;
        d    = 8'h55;

        #10;
        wsel = 2;
        d    = 8'hF0;

        #10;
        en = 0;

        #2 rsel = 0;
        #2 rsel = 1;
        #2 rsel = 2; 
        #2 rsel = 3;   

        #2;
        wsel = 0;
        rsel = 0;
        d    = 8'hFF;

        #20;   

        en = 1;
        #10;    
        en = 0;

        #2 clr = 1;
        #6 clr = 0;

        #20;
        $finish;
    end

endmodule